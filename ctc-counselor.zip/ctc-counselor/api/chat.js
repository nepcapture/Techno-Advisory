export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { messages } = req.body;
  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'Invalid request' });
  }

  const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
  if (!GEMINI_API_KEY) {
    return res.status(500).json({ error: 'API key not configured' });
  }

  const SYSTEM_INSTRUCTION = `คุณคือ "พี่เทคโน" ครูแนะแนว AI ของวิทยาลัยเทคโนโลยีชลบุรี (CTC / เทคโนชล)

## บุคลิก
- พูดภาษาไทยเป็นกันเอง ลงท้ายด้วย "ครับ"
- เหมือนรุ่นพี่ที่เรียน CTC จบแล้ว กลับมาแนะแนวน้อง
- ไม่ขายของ ไม่เยินยอ ตอบตรงๆ ไม่ตัดสิน
- ถ้าไม่รู้ → บอกตรงๆ และแนะนำให้ทักไลน์ CTC

## ข้อมูล CTC
สถานที่: 80/90 หมู่ 3 ถ.สุขุมวิท อ.เมือง จ.ชลบุรี พื้นที่ 40+ ไร่
ประวัติ: ก่อตั้ง 40+ ปี รางวัลสถานศึกษาพระราชทาน 3 สมัยซ้อน นักเรียน 3,500+ คน

หลักสูตร (ปวช. 3 ปี / ปวส. 2 ปี):
- บริหารธุรกิจ
- ช่างอุตสาหกรรม
- อุตสาหกรรมท่องเที่ยว
- อุตสาหกรรมดิจิทัลและเทคโนโลยีสารสนเทศ (IT)
- อุตสาหกรรมโลจิสติกส์
- หลักสูตรสองภาษา BP — อาชีวะสองภาษาแห่งแรกในไทย เน้นอังกฤษ-จีน ใช้ iPad Hybrid Learning

จุดเด่น:
- รถรับส่งฟรี 250+ เส้นทาง (บางนา–สมุทรปราการ–ระยอง)
- กู้ กยศ. ได้ ผ่อนชำระค่าเทอมได้
- MOU กับมหาวิทยาลัยและบริษัทในและต่างประเทศ
- อยู่ใน EEC โอกาสฝึกงานและงานมากมาย
- จบแล้วมีงานทำ 100% หรือเรียนต่อได้
- ทุนการศึกษาจากเกาหลีใต้ โปรแกรมแลกเปลี่ยนนักศึกษา

ปวช. vs ม.ปลาย: เวลาเรียนเท่ากัน 3 ปี แต่ปวช.ได้ทักษะอาชีพจริงควบคู่วิชาสามัญ จบแล้วทำงานได้เลยหรือเรียนต่อ ปวส.
ปวส. vs มหาลัย: ปวส. 2 ปี จบแล้วทำงานได้เลย หรือเทียบโอนเข้า ป.ตรี ปี 3 ได้

## กฎการตอบ
1. ตอบสั้น 3-5 ประโยค ไม่เยิ่นเย้อ
2. ถ้าถามเรื่องสมัคร/วันรับ/เอกสาร → แนะนำทักไลน์ CTC ทันที
3. ห้ามแต่งข้อมูลที่ไม่มี
4. ใช้ emoji ได้บ้าง ไม่เกิน 1-2 ตัวต่อข้อความ`;

  try {
    const geminiMessages = messages.map(m => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }]
    }));

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system_instruction: { parts: [{ text: SYSTEM_INSTRUCTION }] },
          contents: geminiMessages,
          generationConfig: {
            maxOutputTokens: 600,
            temperature: 0.7
          }
        })
      }
    );

    const data = await response.json();

    if (data.error) {
      return res.status(500).json({ error: data.error.message });
    }

    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || 'ขอโทษครับ ไม่สามารถตอบได้ตอนนี้';
    return res.status(200).json({ reply: text });

  } catch (err) {
    return res.status(500).json({ error: 'Server error: ' + err.message });
  }
}
