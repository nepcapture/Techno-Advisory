# พี่เทคโน AI ครูแนะแนว CTC

## โครงสร้างไฟล์
```
ctc-counselor/
├── vercel.json          ← config routing
├── api/
│   └── chat.js         ← Serverless Function (ซ่อน API key)
└── public/
    └── index.html      ← UI หน้าเว็บ
```

## วิธี Deploy บน Vercel (ทำครั้งเดียว ~10 นาที)

### 1. สมัคร Gemini API Key (ฟรี)
- ไปที่ https://aistudio.google.com/apikey
- กด "Create API Key"
- Copy key ไว้

### 2. Upload ขึ้น GitHub
- สมัคร github.com (ถ้ายังไม่มี)
- สร้าง repo ใหม่ ชื่อ `ctc-counselor`
- Upload ไฟล์ทั้งหมดในโฟลเดอร์นี้

### 3. Deploy บน Vercel
- ไปที่ https://vercel.com
- กด "Add New Project" → Import จาก GitHub
- เลือก repo `ctc-counselor`
- กด Deploy

### 4. ใส่ Gemini API Key (สำคัญมาก)
- ใน Vercel Dashboard → Project → Settings → Environment Variables
- กด Add New:
  - Name: `GEMINI_API_KEY`
  - Value: ใส่ key ที่ copy มา
- กด Save
- กด Redeploy (Deployments → Redeploy)

### 5. เสร็จ!
- ได้ URL เช่น `https://ctc-counselor.vercel.app`
- แชร์ให้น้องๆ เปิดใช้ได้เลย

## Gemini Free Tier Limits
- 15 requests/นาที
- 1,000 requests/วัน
- ฟรีตลอด (ไม่หมดอายุ)
- เพียงพอสำหรับ pilot ~500 sessions/เดือน

## อัปเดต LINE OA Link
ใน public/index.html บรรทัดที่มี:
`a.href = 'https://line.me/ti/p/~@technochon';`
เปลี่ยน `@technochon` เป็น LINE ID จริงของ CTC
